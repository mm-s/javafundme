// Set your addresses and GoFundMe URL
window.CONFIG = {
  BTC: "bc1qexample...",                  // Bitcoin address
  LIGHTNING: "yourname@getalby.com",     // Lightning Address (LNURL-pay)
  ETH: "0xYourEthAddress",               // Ethereum address
  GOFUNDME_URL: "",                      // If empty, page uses content.json fallback
  GOAL_USD: null,                        // Set to override content.json goal
  RAISED_USD: null                       // Manually track progress for now
};
